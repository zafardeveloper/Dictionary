import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.cardview.widget.CardView
import androidx.appcompat.widget.SwitchCompat
import com.example.bottomnavigation_practise.R

class ThirdFragment : Fragment() {

    private lateinit var themeSwitcher: SwitchCompat
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_third, container, false)

        val cardViewSwitcher = view.findViewById<CardView>(R.id.cardView_switcher)
        themeSwitcher = view.findViewById(R.id.themeSwitcher)
        sharedPreferences = requireActivity().getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)

        if (savedInstanceState == null) {
            themeSwitcher.isChecked = getCurrentTheme() == AppCompatDelegate.MODE_NIGHT_YES

            cardViewSwitcher.setOnClickListener {
                toggleTheme()
            }

            themeSwitcher.setOnClickListener {
                toggleTheme()
            }
        }

        return view
    }

    private fun toggleTheme() {
        val currentTheme = getCurrentTheme()
        if (currentTheme == AppCompatDelegate.MODE_NIGHT_YES) {
            saveTheme(AppCompatDelegate.MODE_NIGHT_NO)
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        } else {
            saveTheme(AppCompatDelegate.MODE_NIGHT_YES)
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }
        requireActivity().recreate()
    }



    private fun getCurrentTheme(): Int {
        return sharedPreferences.getInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
    }

    private fun saveTheme(themeMode: Int) {
        sharedPreferences.edit().putInt("theme_mode", themeMode).apply()
    }
}

