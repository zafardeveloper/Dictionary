package com.example.bottomnavigation_practise.model.model

data class Word(val tajWord: String, val rusWord: String, var isFavorite: Boolean = false)
