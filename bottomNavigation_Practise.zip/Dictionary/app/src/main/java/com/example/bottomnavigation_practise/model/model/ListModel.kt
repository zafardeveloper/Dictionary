package com.example.bottomnavigation_practise.model.model

class ListModel (
    val tajWord: String,
    val rusWord: String
)

